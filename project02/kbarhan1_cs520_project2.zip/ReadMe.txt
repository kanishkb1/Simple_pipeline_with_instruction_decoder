		***Project-2: Simple Pipeline***

		CS520: Computer Architecture  & Organization
		Name: Kanishk Barhanpurkar
		Email: kbarhan1@binghamton.edu


		
